'use strict';
/* npm test: boots the API in-process and walks the main flows for both roles. */
const http = require('http'), { handle } = require('./routes'); const assert = require('assert');
const srv = http.createServer(handle).listen(0, async () => {
  const base = 'http://localhost:' + srv.address().port; let n = 0;
  const call = async (m, p, tok, body, raw) => { const r = await fetch(base + p, { method: m, headers: { ...(tok ? { authorization: 'Bearer ' + tok } : {}), ...(body && !raw ? { 'content-type': 'application/json' } : {}), ...(raw || {}) }, body: raw ? body : body ? JSON.stringify(body) : undefined }); return { s: r.status, j: await r.json().catch(() => null) }; };
  const ok = (c, msg) => { assert(c, msg); n++; };
  try {
    ok((await call('GET', '/api/health')).j.ok, 'health');
    ok((await call('POST', '/api/auth/login', null, { email: 'riya@medmemory.in', password: 'bad' })).s === 401, 'bad login');
    const riya = (await call('POST', '/api/auth/login', null, { email: 'riya@medmemory.in', password: 'demo123' })).j.token;
    const aman = (await call('POST', '/api/auth/login', null, { email: 'aman@medmemory.in', password: 'demo123' })).j.token;
    const priya = (await call('POST', '/api/auth/login', null, { email: 'priya@medmemory.in', password: 'demo123' })).j.token;
    const arjun = (await call('POST', '/api/auth/login', null, { email: 'arjun@medmemory.in', password: 'demo123' })).j.token;
    const ov = (await call('GET', '/api/patient/overview', riya)).j; ok(ov.history.length && ov.trends.some(t => t.previous) && ov.reminders.length && ov.timeline.length, 'overview');
    ok((await call('GET', '/api/doctor/dashboard', riya)).s === 403, 'role guard');
    const c1 = (await call('POST', '/api/patient/chat', riya, { message: 'Mujhe stress kam karne ke liye kuch yoga batao' })).j; ok(c1.meta.conflicts_avoided.join().includes('Headstand') && c1.meta.record_items_used.length, 'yoga conflict guard');
    const c2 = (await call('POST', '/api/patient/chat', riya, { message: 'I have a chest pain with sweating' })).j; ok(c2.meta.red_flag && c2.meta.urgency === 'emergency', 'red flag');
    const c3 = (await call('POST', '/api/patient/chat', riya, { message: 'Which antibiotic for sore throat?' })).j; ok(c3.meta.conflicts_avoided.join().toLowerCase().includes('penicillin'), 'antibiotic guard');
    ok((await call('POST', '/api/patient/medicine-check', riya, { medicine: 'Amoxicillin' })).j.verdict === 'avoid', 'penicillin allergy');
    ok((await call('POST', '/api/patient/medicine-check', riya, { medicine: 'Ibuprofen' })).j.verdict === 'caution', 'nsaid asthma');
    ok((await call('POST', '/api/patient/medicine-check', riya, { medicine: 'Paracetamol' })).j.verdict === 'safe', 'paracetamol');
    const b = '----x'; const mp = f => Buffer.from(Object.entries(f).map(([k, v]) => `--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`).join('') + `--${b}--\r\n`);
    const rep = await call('POST', '/api/patient/reports', riya, mp({ title: 'Test', text: 'Date: 2026-11-20\nFasting Blood Sugar: 131 mg/dL (70-100)\nHbA1c: 6.9 %\nVitamin D: 35 ng/mL' }), { 'content-type': 'multipart/form-data; boundary=' + b });
    ok(rep.s === 200 && rep.j.values.length === 3 && rep.j.values[0].status === 'high', 'report parse');
    const sl = (await call('GET', '/api/doctors/2/slots', riya)).j; ok(sl.length && sl[0].slots[0].includes('T'), 'slots');
    const bk = await call('POST', '/api/appointments', riya, { doctor_id: 2, slot: sl[1].slots[0], reason: 'Test visit' }); ok(bk.s === 200, 'book');
    ok((await call('POST', '/api/appointments', riya, { doctor_id: 2, slot: sl[1].slots[0], reason: 'Dup' })).s === 409, 'double book blocked');
    const dd = (await call('GET', '/api/doctor/dashboard', priya)).j; ok(dd.stats.today === 3 && dd.notifications.some(x => x.kind === 'follow_up_overdue'), 'doctor dashboard');
    const pl = (await call('GET', '/api/doctor/patients', priya)).j; ok(pl.length === 3, 'patients');
    const amanId = pl.find(p => p.name === 'Aman Kumar').id; ok((await call('GET', '/api/doctor/patients/' + amanId, priya)).j.trends.length, 'patient detail');
    ok((await call('GET', '/api/doctor/patients/' + amanId, arjun)).s === 403, 'doctor access control');
    const br = await call('POST', `/api/doctor/patients/${amanId}/ai-summary`, priya); ok(br.j.allergies_alerts.length && br.j.report_changes.length, 'brief');
    const amanAppt = dd.today.find(a => a.patient_name === 'Aman Kumar'); ok((await call('POST', `/api/doctor/appointments/${amanAppt.id}/start`, priya)).j.status === 'in_progress', 'start');
    const cr = (await call('GET', `/api/doctor/consultations/by-appointment/${amanAppt.id}`, priya)).j; ok(cr.consultation, 'consult room');
    ok((await call('POST', `/api/appointments/${amanAppt.id}/messages`, aman, { text: 'Hello doctor' })).s === 200, 'patient msg');
    ok((await call('GET', `/api/appointments/${amanAppt.id}/messages`, priya)).j.length === 2, 'messages');
    ok((await call('PUT', `/api/doctor/consultations/${cr.consultation.id}`, priya, { notes: 'Fatigue, high sugar', diagnosis: 'T2DM uncontrolled', prescription: 'Increase metformin', follow_up_date: '2026-12-10' })).s === 200, 'save');
    const done = await call('POST', `/api/doctor/consultations/${cr.consultation.id}/complete`, priya, {}); ok(done.s === 200 && JSON.parse(done.j.ai_summary).plan.length, 'complete + summary');
    ok((await call('GET', '/api/patient/consultations', aman)).j.length === 2, 'patient consultations');
    ok((await call('GET', '/api/patient/emergency-card', riya)).j.qr_svg.includes('<svg'), 'emergency card');
    const su = await call('POST', '/api/auth/signup', null, { name: 'Test User', email: 'test@x.in', password: 'secret1', age: 30 }); ok(su.s === 200 && su.j.user.role === 'patient', 'signup');
    ok((await call('POST', '/api/auth/signup', null, { name: 'T', email: 'test@x.in', password: 'secret1' })).s === 400, 'dup email');
    console.log(`All ${n} checks passed.`);
  } catch (e) { console.error('FAILED:', e.message, '\n', e.stack.split('\n')[1]); process.exitCode = 1; } finally { srv.close(); }
});
