'use strict';
const crypto = require('crypto');
const SECRET = () => process.env.JWT_SECRET || 'medmemory-dev-secret-change-me';
const istNow = () => new Date(Date.now() + 5.5 * 3600e3);
const today = () => istNow().toISOString().slice(0, 10);
const addDays = (n, base) => { const d = base ? new Date(base + 'T00:00:00Z') : new Date(today() + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const stamp = () => new Date().toISOString().slice(0, 19);

let S = null, pool = null, ready = null, saving = false, dirty = false;
const blank = () => ({ seq: {}, users: [], doctors: [], profiles: [], history: [], allergies: [], meds: [], symptoms: [], reports: [], labs: [], appts: [], consults: [], msgs: [], chats: [] });
const nid = k => (S.seq[k] = (S.seq[k] || 0) + 1);
const hash = (pw, salt = crypto.randomBytes(8).toString('hex')) => salt + ':' + crypto.pbkdf2Sync(pw, salt, 20000, 32, 'sha256').toString('hex');
const verify = (pw, h) => { const [salt] = h.split(':'); const x = hash(pw, salt); return x.length === h.length && crypto.timingSafeEqual(Buffer.from(x), Buffer.from(h)); };

const b64 = b => Buffer.from(b).toString('base64url');
function sign(user) { const h = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' })), p = b64(JSON.stringify({ sub: user.id, role: user.role, exp: Math.floor(Date.now() / 1000) + 7 * 86400 })); return `${h}.${p}.${crypto.createHmac('sha256', SECRET()).update(h + '.' + p).digest('base64url')}`; }
function decode(tok) { try { const [h, p, s] = tok.split('.'); const e = crypto.createHmac('sha256', SECRET()).update(h + '.' + p).digest('base64url'); if (s !== e) return null; const j = JSON.parse(Buffer.from(p, 'base64url')); return j.exp * 1000 > Date.now() ? j : null; } catch { return null; } }

/* ---------- persistence: optional PostgreSQL snapshot (set DATABASE_URL) ---------- */
async function init() {
  if (ready) return ready;
  ready = (async () => {
    const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
    if (url) {
      try {
        const { Pool } = require('pg');
        pool = new Pool({ connectionString: url, ssl: /localhost|127\.0\.0\.1/.test(url) ? false : { rejectUnauthorized: false }, max: 1 });
        await pool.query('CREATE TABLE IF NOT EXISTS medmemory_state (id INT PRIMARY KEY, data JSONB NOT NULL, updated_at TIMESTAMPTZ DEFAULT now())');
        const r = await pool.query('SELECT data FROM medmemory_state WHERE id=1');
        if (r.rows[0]) { S = r.rows[0].data; return; }
      } catch (e) { console.error('Postgres unavailable, using in-memory data:', e.message); pool = null; }
    }
    S = blank(); seed(); await persist();
  })();
  return ready;
}
async function persist() {
  if (!pool) return; dirty = true; if (saving) return; saving = true;
  try { while (dirty) { dirty = false; await pool.query('INSERT INTO medmemory_state (id,data) VALUES (1,$1) ON CONFLICT (id) DO UPDATE SET data=$1, updated_at=now()', [JSON.stringify(S)]); } }
  catch (e) { console.error('persist failed', e.message); } finally { saving = false; }
}

/* ---------- seed (dummy data, dates are relative to today) ---------- */
function seed() {
  const U = (name, email, role) => { const u = { id: nid('u'), name, email, password_hash: hash('demo123'), role, created_at: stamp() }; S.users.push(u); return u; };
  const P = (u, o) => S.profiles.push({ user_id: u.id, age: null, gender: '', blood_group: '', height_cm: null, weight_kg: null, phone: '', emergency_contact: '', share_with_doctors: true, ...o });
  const D = (name, email, o) => { const u = U(name, email, 'doctor'); const d = { id: nid('d'), user_id: u.id, languages: 'English, Hindi', ...o }; S.doctors.push(d); return d; };
  const dPriya = D('Dr. Priya Sharma', 'priya@medmemory.in', { specialty: 'General Physician', qualification: 'MBBS, MD (Medicine)', rating: 4.8, experience_years: 12, hospital: 'Max Healthcare, Saket', bio: 'Family medicine, diabetes and preventive health.', fee: 700 });
  const dArjun = D('Dr. Arjun Rao', 'arjun@medmemory.in', { specialty: 'Orthopaedics', qualification: 'MBBS, MS (Ortho)', rating: 4.7, experience_years: 15, hospital: 'Fortis Hospital, Noida', bio: 'Spine, neck and sports injuries.', fee: 900 });
  D('Dr. Meera Iyer', 'meera@medmemory.in', { specialty: 'Cardiology', qualification: 'MBBS, DM (Cardiology)', rating: 4.9, experience_years: 18, hospital: 'Apollo Hospital, Delhi', bio: 'Heart health, hypertension and cholesterol.', fee: 1200 });
  D('Dr. Kabir Sethi', 'kabir@medmemory.in', { specialty: 'Endocrinology', qualification: 'MBBS, DM (Endocrinology)', rating: 4.8, experience_years: 14, hospital: 'AIIMS Outpatient, Delhi', bio: 'Diabetes, thyroid and hormone disorders.', fee: 1100 });
  D('Dr. Ananya Das', 'ananya@medmemory.in', { specialty: 'Dermatology', qualification: 'MBBS, MD (Dermatology)', rating: 4.6, experience_years: 9, hospital: 'Medanta, Gurugram', bio: 'Skin, hair and allergy care.', fee: 800, languages: 'English, Hindi, Bengali' });
  D('Dr. Rohan Mehta', 'rohan@medmemory.in', { specialty: 'Neurology', qualification: 'MBBS, DM (Neurology)', rating: 4.7, experience_years: 11, hospital: 'Fortis Hospital, Noida', bio: 'Headache, migraine and nerve problems.', fee: 1000 });
  const riya = U('Riya Sharma', 'riya@medmemory.in', 'patient'); P(riya, { age: 26, gender: 'Female', blood_group: 'B+', height_cm: 162, weight_kg: 58, phone: '+91 98100 11122', emergency_contact: 'Anil Sharma (father) · +91 98100 33344' });
  const aman = U('Aman Kumar', 'aman@medmemory.in', 'patient'); P(aman, { age: 54, gender: 'Male', blood_group: 'O+', height_cm: 170, weight_kg: 82, phone: '+91 98200 55566', emergency_contact: 'Sunita Kumar (wife) · +91 98200 77788' });
  const neha = U('Neha Verma', 'neha@medmemory.in', 'patient'); P(neha, { age: 31, gender: 'Female', blood_group: 'A+', phone: '+91 98300 99900', emergency_contact: 'Rahul Verma · +91 98300 12121' });
  const H = (u, o) => S.history.push({ id: nid('h'), user_id: u.id, body_part: '', notes: '', ...o });
  H(riya, { type: 'injury', name: 'Neck strain', body_part: 'Cervical spine', date: addDays(-33), status: 'recovering', notes: 'Desk posture. Physio advised.' });
  H(riya, { type: 'illness', name: 'Asthma', date: addDays(-2200), status: 'chronic', notes: 'Mild, seasonal.' });
  H(aman, { type: 'illness', name: 'Type 2 diabetes', date: addDays(-1800), status: 'chronic', notes: 'On metformin.' });
  H(aman, { type: 'illness', name: 'Hypertension', date: addDays(-1500), status: 'chronic' });
  H(neha, { type: 'illness', name: 'Seasonal allergic rhinitis', date: addDays(-700), status: 'recovering' });
  const A = (u, o) => S.allergies.push({ id: nid('a'), user_id: u.id, reaction: '', ...o });
  A(riya, { allergen: 'Penicillin', category: 'drug', severity: 'severe', reaction: 'Rash and swelling' });
  A(aman, { allergen: 'Sulfa drugs', category: 'drug', severity: 'moderate', reaction: 'Skin rash' });
  A(neha, { allergen: 'Dust', category: 'environment', severity: 'mild', reaction: 'Sneezing' });
  const M = (u, o) => S.meds.push({ id: nid('m'), user_id: u.id, ...o });
  M(riya, { name: 'Salbutamol inhaler', dosage: 'As needed', since: addDays(-2000) });
  M(aman, { name: 'Metformin', dosage: '500 mg twice daily', since: addDays(-1700) }); M(aman, { name: 'Amlodipine', dosage: '5 mg once daily', since: addDays(-1400) });
  S.symptoms.push({ id: nid('s'), user_id: riya.id, description: 'Mild evening headache', severity: 3, logged_at: addDays(-1) + 'T19:00:00' });
  S.symptoms.push({ id: nid('s'), user_id: aman.id, description: 'Feeling thirsty and tired', severity: 4, logged_at: addDays(-3) + 'T09:30:00' });
  const R = (u, daysBack, title, type, summary, findings, vals) => { const r = { id: nid('r'), user_id: u.id, title, report_type: type, report_date: addDays(-daysBack), filename: null, mime: null, file_b64: null, summary, key_findings: findings }; S.reports.push(r);
    vals.forEach(([t, v, unit, st, range]) => S.labs.push({ id: nid('l'), report_id: r.id, user_id: u.id, test_name: t, value: v, unit, status: st, normal_range: range, date: r.report_date })); };
  R(riya, 130, 'Routine blood test', 'Blood test', 'All values were in a healthy range.', ['All extracted values are in the normal range.'], [['Fasting Blood Sugar', 96, 'mg/dL', 'normal', '70-100'], ['HbA1c', 5.5, '%', 'normal', '4.0-5.6'], ['Vitamin D', 22, 'ng/mL', 'low', '30-100'], ['Haemoglobin', 12.6, 'g/dL', 'normal', '12-15.5']]);
  R(riya, 9, 'Health checkup panel', 'Blood test', 'Blood sugar has crept up since the last test and vitamin D is low. Not diagnostic, but worth a doctor review.', ['Fasting Blood Sugar is 118 mg/dL — above the normal range (70-100).', 'HbA1c is 6.3 % — above the normal range (4.0-5.6).', 'Vitamin D is 18 ng/mL — below the normal range (30-100).'], [['Fasting Blood Sugar', 118, 'mg/dL', 'high', '70-100'], ['HbA1c', 6.3, '%', 'high', '4.0-5.6'], ['Vitamin D', 18, 'ng/mL', 'low', '30-100'], ['Haemoglobin', 12.4, 'g/dL', 'normal', '12-15.5']]);
  R(aman, 120, 'Diabetes review', 'Diabetes panel', 'Sugar control was above target.', ['HbA1c is 7.2 % — above the normal range (4.0-5.6).', 'Fasting Blood Sugar is 142 mg/dL — above the normal range.'], [['HbA1c', 7.2, '%', 'high', '4.0-5.6'], ['Fasting Blood Sugar', 142, 'mg/dL', 'high', '70-100'], ['Total Cholesterol', 204, 'mg/dL', 'high', '<200']]);
  R(aman, 6, 'Diabetes follow-up panel', 'Diabetes panel', 'HbA1c and fasting sugar are higher than the last report and cholesterol is above range.', ['HbA1c rose from 7.2 to 7.8 %.', 'Fasting Blood Sugar is 156 mg/dL — above the normal range.', 'Total Cholesterol is 218 mg/dL — above the normal range.'], [['HbA1c', 7.8, '%', 'high', '4.0-5.6'], ['Fasting Blood Sugar', 156, 'mg/dL', 'high', '70-100'], ['Total Cholesterol', 218, 'mg/dL', 'high', '<200']]);
  const slot = (d, hm) => `${d}T${hm}:00`; const nextDay = n => { let d = addDays(n); while (new Date(d + 'T00:00:00Z').getUTCDay() === 0) d = addDays(1, d); return d; };
  const AP = (p, d, when, reason, status, ai) => { const a = { id: nid('p'), patient_id: p.id, doctor_id: d.id, slot: when, reason, status, booked_via_ai: !!ai }; S.appts.push(a); return a; };
  const old = AP(aman, dPriya, slot(addDays(-45), '11:00'), 'Diabetes review', 'completed');
  S.consults.push({ id: nid('c'), appointment_id: old.id, notes: 'Sugar above target. Diet counselling given. Continue metformin, review in 4 weeks.', diagnosis: 'Type 2 diabetes, suboptimal control', prescription: 'Metformin 500 mg BD; Amlodipine 5 mg OD', follow_up_date: addDays(-14), follow_up_done: false, ai_summary: JSON.stringify({ chief_complaint: 'Diabetes review', diagnosis: 'Type 2 diabetes, suboptimal control', findings: ['Sugar above target'], plan: ['Continue metformin', 'Review in 4 weeks'], patient_instructions: ['Reduce sugar and refined carbs', 'Walk 30 minutes daily'], follow_up: addDays(-14) }), brief: null, completed_at: addDays(-45) + 'T11:40:00' });
  AP(aman, dPriya, slot(today(), '11:00'), 'Sugar follow-up and fatigue', 'booked'); AP(neha, dPriya, slot(today(), '12:30'), 'Seasonal allergy symptoms', 'booked'); AP(riya, dPriya, slot(today(), '15:30'), 'Vitamin D and sugar results', 'booked', true);
  AP(riya, dArjun, slot(nextDay(1), '10:30'), 'Neck pain after desk work', 'booked', true);
  S.chats.push({ id: nid('ch'), user_id: riya.id, role: 'assistant', content: 'Hi Riya, I have your record loaded: neck strain, asthma and your penicillin allergy. Ask me anything and I will check it against your history first.', meta: { urgency: 'low', follow_up_questions: ['Suggest yoga for stress', 'Explain my latest report'] }, created_at: stamp() });
}
module.exports = { init, persist, get S() { return S; }, nid, hash, verify, sign, decode, today, addDays, stamp, istNow };
