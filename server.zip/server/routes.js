'use strict';
const st = require('./store'), ai = require('./ai');
const HttpError = (code, detail) => Object.assign(new Error(detail), { code, detail });
const S = () => st.S;
const byId = (arr, id) => arr.find(x => x.id === +id);
const desc = (a, k) => [...a].sort((x, y) => String(y[k] || '').localeCompare(String(x[k] || '')));
const user = id => byId(S().users, id);
const prof = uid => S().profiles.find(p => p.user_id === uid) || {};
const docByUser = uid => S().doctors.find(d => d.user_id === uid);
const docView = d => { const u = user(d.user_id); const { user_id, ...r } = d; return { ...r, name: u.name }; };
const userView = u => { const o = { id: u.id, name: u.name, email: u.email, role: u.role }; if (u.role === 'patient') o.profile = prof(u.id); else { const d = docByUser(u.id); o.doctor = d ? docView(d) : null; } return o; };

/* ---------- derived views ---------- */
function trendsFor(uid) {
  const g = {}; S().labs.filter(l => l.user_id === uid).forEach(l => (g[l.test_name] = g[l.test_name] || []).push(l));
  return Object.entries(g).map(([test, ls]) => {
    ls.sort((a, b) => a.date.localeCompare(b.date) || a.id - b.id); const last = ls[ls.length - 1], prev = ls[ls.length - 2];
    const ch = prev ? +(last.value - prev.value).toFixed(2) : 0;
    return { test, unit: last.unit, normal_range: last.normal_range, direction: !prev || ch === 0 ? 'flat' : ch > 0 ? 'up' : 'down', change: ch,
      points: ls.map(l => ({ date: l.date, value: l.value, status: l.status })), previous: prev ? { value: prev.value, date: prev.date, status: prev.status } : undefined, latest: { value: last.value, date: last.date, status: last.status } };
  });
}
const reportView = (r, withFile) => ({ id: r.id, title: r.title, report_type: r.report_type, report_date: r.report_date, filename: r.filename, has_file: !!r.file_b64, summary: r.summary, key_findings: r.key_findings || [],
  values: S().labs.filter(l => l.report_id === r.id).map(({ id, test_name, value, unit, status, normal_range }) => ({ id, test_name, value, unit, status, normal_range })) });
const consView = c => { const a = byId(S().appts, c.appointment_id); const d = byId(S().doctors, a.doctor_id), p = user(a.patient_id); const { brief, ...r } = c;
  return { ...r, patient_id: a.patient_id, patient_name: p.name, doctor_name: user(d.user_id).name, reason: a.reason, slot: a.slot }; };
const apptView = a => { const d = byId(S().doctors, a.doctor_id), c = S().consults.find(x => x.appointment_id === a.id);
  return { ...a, patient_name: user(a.patient_id).name, doctor_name: user(d.user_id).name, specialty: d.specialty, hospital: d.hospital, consultation: c ? consView(c) : null }; };
function record(uid) {
  const u = user(uid), s = S();
  const rec = { user: { id: u.id, name: u.name, email: u.email }, profile: prof(uid), history: desc(s.history.filter(h => h.user_id === uid), 'date'), allergies: s.allergies.filter(a => a.user_id === uid), medications: s.meds.filter(m => m.user_id === uid),
    symptoms: desc(s.symptoms.filter(x => x.user_id === uid), 'logged_at'), reports: desc(s.reports.filter(r => r.user_id === uid), 'report_date').map(r => reportView(r)), trends: trendsFor(uid) };
  return rec;
}
function timeline(uid) {
  const s = S(), out = [];
  s.history.filter(h => h.user_id === uid).forEach(h => out.push({ kind: ['injury', 'illness', 'surgery'].includes(h.type) ? h.type : 'illness', title: h.name, date: h.date, detail: h.notes || h.status }));
  s.reports.filter(r => r.user_id === uid).forEach(r => out.push({ kind: 'report', title: r.title, date: r.report_date, detail: (r.key_findings || [])[0] || r.summary }));
  s.appts.filter(a => a.patient_id === uid).forEach(a => { const c = s.consults.find(x => x.appointment_id === a.id && x.completed_at); const d = user(byId(s.doctors, a.doctor_id).user_id);
    out.push(c ? { kind: 'consultation', title: `Consultation with ${d.name}`, date: a.slot.slice(0, 10), detail: c.diagnosis } : { kind: 'appointment', title: `${a.status === 'cancelled' ? 'Cancelled' : 'Appointment'}: ${d.name}`, date: a.slot.slice(0, 10), detail: a.reason }); });
  return desc(out, 'date');
}
function docFor(spec) { return S().doctors.find(d => d.specialty === spec); }
function reminders(uid, rec) {
  const out = [];
  rec.trends.forEach(t => { if (t.latest.status !== 'normal') { const sp = /hba1c|sugar|glucose/i.test(t.test) ? 'Endocrinology' : /cholesterol|ldl|triglyc|heart/i.test(t.test) ? 'Cardiology' : 'General Physician'; const d = docFor(sp);
    out.push({ level: t.direction === 'up' && t.latest.status === 'high' ? 'high' : 'medium', text: `${t.test} is ${t.latest.status}${t.previous ? ` (${t.previous.value} → ${t.latest.value} ${t.unit || ''})` : ''}. Consider seeing a ${sp} doctor.`, doctor_id: d && d.id }); } });
  S().consults.forEach(c => { const a = byId(S().appts, c.appointment_id); if (a.patient_id === uid && c.follow_up_date && !c.follow_up_done && c.follow_up_date < st.today() && !S().appts.some(x => x.patient_id === uid && x.doctor_id === a.doctor_id && x.status === 'booked' && x.slot.slice(0, 10) > st.today()))
    out.push({ level: 'high', text: `Follow-up was due on ${c.follow_up_date}. Please book your follow-up visit.`, doctor_id: a.doctor_id }); });
  if (rec.symptoms[0] && rec.symptoms[0].severity >= 7) out.push({ level: 'high', text: `You logged "${rec.symptoms[0].description}" at ${rec.symptoms[0].severity}/10. Please get it checked.`, doctor_id: (docFor('General Physician') || {}).id });
  return out.sort((a, b) => ({ high: 0, medium: 1, low: 2 }[a.level] - { high: 0, medium: 1, low: 2 }[b.level]));
}
function accessible(doctor, pid) { const p = prof(pid); if (p.share_with_doctors === false) return false; return S().appts.some(a => a.doctor_id === doctor.id && a.patient_id === pid && a.status !== 'cancelled'); }
function docNotifs(doctor) {
  const out = [], s = S(), pids = [...new Set(s.appts.filter(a => a.doctor_id === doctor.id && a.status !== 'cancelled').map(a => a.patient_id))].filter(p => accessible(doctor, p));
  pids.forEach(pid => { const name = user(pid).name, rec = record(pid);
    s.consults.forEach(c => { const a = byId(s.appts, c.appointment_id); if (a.patient_id !== pid || a.doctor_id !== doctor.id || !c.follow_up_date || c.follow_up_done) return;
      const later = s.appts.some(x => x.patient_id === pid && x.doctor_id === doctor.id && x.status === 'booked' && x.slot.slice(0, 10) > st.today() && x.id !== a.id);
      if (c.follow_up_date < st.today() && !later) out.push({ kind: 'follow_up_overdue', level: 'high', patient_id: pid, patient_name: name, consultation_id: c.id, text: `Follow-up was due on ${c.follow_up_date} and is still open.` });
      else if (c.follow_up_date >= st.today() && c.follow_up_date <= st.addDays(3)) out.push({ kind: 'follow_up_due', level: 'medium', patient_id: pid, patient_name: name, consultation_id: c.id, text: `Follow-up due on ${c.follow_up_date}.` }); });
    rec.trends.forEach(t => { if (t.previous && t.direction === 'up' && t.latest.status === 'high') out.push({ kind: 'abnormal_trend', level: 'medium', patient_id: pid, patient_name: name, text: `${t.test} rising ${t.previous.value} → ${t.latest.value} ${t.unit || ''} (above range).` }); });
    s.reports.filter(r => r.user_id === pid && r.report_date >= st.addDays(-5)).forEach(r => out.push({ kind: 'new_report', level: 'low', patient_id: pid, patient_name: name, text: `Uploaded a new report: ${r.title}.` }));
    s.chats.filter(c => c.user_id === pid && c.meta && c.meta.red_flag && c.created_at >= st.addDays(-7)).slice(-1).forEach(c => out.push({ kind: 'red_flag', level: 'high', patient_id: pid, patient_name: name, text: `AI flagged a possible emergency: ${c.meta.red_flag_reason}` })); });
  return out.sort((a, b) => ({ high: 0, medium: 1, low: 2 }[a.level] - { high: 0, medium: 1, low: 2 }[b.level]));
}
function slotsFor(d) {
  const now = st.istNow(), out = [], taken = new Set(S().appts.filter(a => a.doctor_id === d.id && a.status !== 'cancelled').map(a => a.slot));
  for (let i = 0; i < 8 && out.length < 6; i++) { const date = st.addDays(i); if (new Date(date + 'T00:00:00Z').getUTCDay() === 0) continue; const sl = [];
    for (let h = 10; h <= 16; h++) for (const m of ['00', '30']) { if (h === 16 && m === '30') continue; const iso = `${date}T${String(h).padStart(2, '0')}:${m}:00`; if (taken.has(iso)) continue; if (i === 0 && new Date(iso + 'Z') <= now) continue; sl.push(iso); }
    if (sl.length) out.push({ date, slots: sl }); }
  return out;
}

/* ---------- multipart ---------- */
function multipart(buf, ctype) {
  const b = (ctype.match(/boundary=(?:"([^"]+)"|([^;]+))/) || []); const bound = Buffer.from('--' + (b[1] || b[2])); const fields = {}, files = {};
  let pos = buf.indexOf(bound);
  while (pos !== -1) { const next = buf.indexOf(bound, pos + bound.length); if (next === -1) break; const part = buf.slice(pos + bound.length + 2, next - 2); const he = part.indexOf('\r\n\r\n'); if (he > -1) { const head = part.slice(0, he).toString(), body = part.slice(he + 4);
    const name = (head.match(/name="([^"]*)"/) || [])[1], fn = (head.match(/filename="([^"]*)"/) || [])[1], mime = (head.match(/Content-Type:\s*([^\r\n]+)/i) || [])[1];
    if (name) { if (fn !== undefined && fn !== '') files[name] = { filename: fn, mime: mime || 'application/octet-stream', data: body }; else if (fn === undefined) fields[name] = body.toString(); } } pos = next; }
  return { fields, files };
}

/* ---------- route table ---------- */
const routes = [];
const R = (method, path, role, fn) => routes.push({ method, re: new RegExp('^' + path.replace(/:[a-z_]+/g, '([^/]+)') + '$'), role, fn });
const need = (c, m) => { if (!c) throw HttpError(400, m); };

R('POST', '/api/auth/login', null, async ({ body }) => { const u = S().users.find(x => x.email.toLowerCase() === String(body.email || '').trim().toLowerCase()); if (!u || !st.verify(String(body.password || ''), u.password_hash)) throw HttpError(401, 'Invalid email or password'); return { token: st.sign(u), user: userView(u) }; });
R('POST', '/api/auth/signup', null, async ({ body }) => {
  const email = String(body.email || '').trim().toLowerCase(); need(body.name && email && body.password, 'Name, email and password are required'); need(String(body.password).length >= 6, 'Password must be at least 6 characters');
  if (S().users.some(x => x.email.toLowerCase() === email)) throw HttpError(400, 'Email already registered');
  const u = { id: st.nid('u'), name: String(body.name).trim(), email, password_hash: st.hash(String(body.password)), role: 'patient', created_at: st.stamp() }; S().users.push(u);
  S().profiles.push({ user_id: u.id, age: body.age ? +body.age : null, gender: body.gender || '', blood_group: body.blood_group || '', height_cm: null, weight_kg: null, phone: '', emergency_contact: '', share_with_doctors: true });
  return { token: st.sign(u), user: userView(u) }; });
R('GET', '/api/auth/me', 'any', async ({ me }) => userView(me));

/* patient */
R('GET', '/api/patient/overview', 'patient', async ({ me }) => { const rec = record(me.id); const appts = desc(S().appts.filter(a => a.patient_id === me.id), 'slot').reverse().map(apptView);
  return { user: userView(me), profile: rec.profile, history: rec.history, allergies: rec.allergies, medications: rec.medications, symptoms: rec.symptoms, reports: rec.reports, appointments: appts, trends: rec.trends, reminders: reminders(me.id, rec), timeline: timeline(me.id) }; });
R('PUT', '/api/patient/profile', 'patient', async ({ me, body }) => { const p = S().profiles.find(x => x.user_id === me.id); ['age', 'gender', 'blood_group', 'height_cm', 'weight_kg', 'phone', 'emergency_contact', 'share_with_doctors'].forEach(k => { if (k in body) p[k] = ['age', 'height_cm', 'weight_kg'].includes(k) ? (body[k] === '' || body[k] == null ? null : +body[k]) : body[k]; }); if (body.name) me.name = String(body.name); return userView(me); });
const KINDS = { history: ['history', ['type', 'name', 'body_part', 'date', 'status', 'notes']], allergies: ['allergies', ['allergen', 'category', 'severity', 'reaction']], medications: ['meds', ['name', 'dosage', 'since']], symptoms: ['symptoms', ['description', 'severity']] };
R('POST', '/api/patient/records/:kind', 'patient', async ({ me, body, m }) => { const k = KINDS[m[1]]; if (!k) throw HttpError(404, 'Unknown record type'); const o = { id: st.nid(m[1][0]), user_id: me.id }; k[1].forEach(f => { if (body[f] !== undefined) o[f] = body[f]; });
  if (m[1] === 'symptoms') { o.severity = +o.severity || 3; o.logged_at = st.stamp(); } if (m[1] === 'history') { o.type = o.type || 'illness'; o.status = o.status || 'active'; o.date = o.date || st.today(); }
  need(o.name || o.allergen || o.description, 'Please fill in the name'); S()[k[0]].push(o); return o; });
R('DELETE', '/api/patient/records/:kind/:id', 'patient', async ({ me, m }) => { const k = KINDS[m[1]]; if (!k) throw HttpError(404, 'Unknown record type'); const arr = S()[k[0]], i = arr.findIndex(x => x.id === +m[2] && x.user_id === me.id); if (i < 0) throw HttpError(404, 'Not found'); arr.splice(i, 1); return { ok: true }; });
R('POST', '/api/patient/medicine-check', 'patient', async ({ me, body }) => { need(body.medicine && String(body.medicine).trim(), 'Enter a medicine name'); return ai.medicineCheck(String(body.medicine), record(me.id)); });
R('GET', '/api/patient/chat', 'patient', async ({ me }) => S().chats.filter(c => c.user_id === me.id).map(({ user_id, ...c }) => c));
R('POST', '/api/patient/chat', 'patient', async ({ me, body }) => { const msg = String(body.message || body.content || '').trim(); need(msg, 'Message is empty'); const rec = record(me.id), hist = S().chats.filter(c => c.user_id === me.id);
  S().chats.push({ id: st.nid('ch'), user_id: me.id, role: 'user', content: msg, meta: null, created_at: st.stamp() });
  const r = await ai.chat(msg, rec, hist); if (r.meta.specialty) { const ds = S().doctors.filter(d => d.specialty === r.meta.specialty); r.meta.doctors = ds.map(docView); }
  const a = { id: st.nid('ch'), user_id: me.id, role: 'assistant', content: r.content, meta: r.meta, created_at: st.stamp() }; S().chats.push(a); const { user_id, ...o } = a; return o; });
R('DELETE', '/api/patient/chat', 'patient', async ({ me }) => { S().chats = S().chats.filter(c => c.user_id !== me.id); return { ok: true }; });
R('POST', '/api/patient/reports', 'patient', async ({ me, raw, ctype }) => {
  need(/multipart/.test(ctype), 'Send the report as form data'); const { fields, files } = multipart(raw, ctype); const f = files.file; const text = fields.text || '';
  need(f || text.trim(), 'Upload a file or paste the report text'); if (f) need(f.data.length <= 4 * 1024 * 1024, 'File too large for hosting (max 4 MB). Use a smaller file or paste the text.');
  let r; try { r = await ai.readReport({ text, file: f }); } catch (e) { throw HttpError(422, e.message); }
  const row = { id: st.nid('r'), user_id: me.id, title: fields.title || r.title || (f ? f.filename.replace(/\.[^.]+$/, '') : 'Pasted report'), report_type: fields.report_type || r.report_type, report_date: fields.report_date || r.report_date || st.today(), filename: f ? f.filename : null, mime: f ? f.mime : null, file_b64: f ? f.data.toString('base64') : null, summary: r.summary, key_findings: r.key_findings }; S().reports.push(row);
  r.values.forEach(v => S().labs.push({ id: st.nid('l'), report_id: row.id, user_id: me.id, test_name: v.test_name, value: v.value, unit: v.unit, status: v.status, normal_range: v.normal_range, date: row.report_date })); return reportView(row); });
R('DELETE', '/api/patient/reports/:id', 'patient', async ({ me, m }) => { const s = S(), i = s.reports.findIndex(r => r.id === +m[1] && r.user_id === me.id); if (i < 0) throw HttpError(404, 'Report not found'); s.reports.splice(i, 1); s.labs = s.labs.filter(l => l.report_id !== +m[1]); return { ok: true }; });
R('GET', '/api/reports/:id', 'any', async ({ me, m }) => { const r = byId(S().reports, m[1]); if (!r) throw HttpError(404, 'Report not found'); const dr = me.role === 'doctor' ? docByUser(me.id) : null; if (r.user_id !== me.id && !(dr && accessible(dr, r.user_id))) throw HttpError(403, 'No access'); return reportView(r); });
R('GET', '/api/reports/:id/file', 'any', async ({ me, m }) => { const r = byId(S().reports, m[1]); if (!r || !r.file_b64) throw HttpError(404, 'No file for this report'); const dr = me.role === 'doctor' ? docByUser(me.id) : null; if (r.user_id !== me.id && !(dr && accessible(dr, r.user_id))) throw HttpError(403, 'No access'); return { filename: r.filename, mime: r.mime, data: r.file_b64 }; });
R('GET', '/api/patient/emergency-card', 'patient', async ({ me }) => { const rec = record(me.id), p = rec.profile; const o = { name: me.name, age: p.age, blood_group: p.blood_group, allergies: rec.allergies.map(a => `${a.allergen} (${a.severity})`), conditions: rec.history.filter(h => h.status !== 'recovered').map(h => h.name), medications: rec.medications.map(m => `${m.name} ${m.dosage || ''}`.trim()), emergency_contact: p.emergency_contact };
  const txt = `MEDMEMORY EMERGENCY\n${o.name}${o.age ? ', ' + o.age + 'y' : ''}\nBlood: ${o.blood_group || '?'}\nAllergies: ${o.allergies.join(', ') || 'none'}\nConditions: ${o.conditions.join(', ') || 'none'}\nMeds: ${o.medications.join(', ') || 'none'}\nContact: ${o.emergency_contact || '-'}`;
  o.qr_svg = require('./qr').svg(txt); return o; });
R('GET', '/api/patient/consultations', 'patient', async ({ me }) => S().consults.filter(c => c.completed_at && byId(S().appts, c.appointment_id).patient_id === me.id).map(consView).sort((a, b) => b.completed_at.localeCompare(a.completed_at)));

/* doctors & appointments */
R('GET', '/api/doctors', 'any', async ({ q }) => S().doctors.filter(d => !q.specialty || d.specialty === q.specialty).map(docView));
R('GET', '/api/doctors/:id/slots', 'any', async ({ m }) => { const d = byId(S().doctors, m[1]); if (!d) throw HttpError(404, 'Doctor not found'); return slotsFor(d); });
R('POST', '/api/appointments', 'patient', async ({ me, body }) => { const d = byId(S().doctors, body.doctor_id); if (!d) throw HttpError(404, 'Doctor not found'); const ok = slotsFor(d).some(x => x.slots.includes(body.slot)); if (!ok) throw HttpError(409, 'That slot is no longer available'); need(String(body.reason || '').trim(), 'Please add a reason for the visit');
  const a = { id: st.nid('p'), patient_id: me.id, doctor_id: d.id, slot: body.slot, reason: String(body.reason).trim(), status: 'booked', booked_via_ai: !!body.booked_via_ai }; S().appts.push(a); return apptView(a); });
R('POST', '/api/appointments/:id/cancel', 'patient', async ({ me, m }) => { const a = byId(S().appts, m[1]); if (!a || a.patient_id !== me.id) throw HttpError(404, 'Appointment not found'); if (a.status !== 'booked') throw HttpError(400, 'Only booked appointments can be cancelled'); a.status = 'cancelled'; return apptView(a); });
function apptAccess(me, id) { const a = byId(S().appts, id); if (!a) throw HttpError(404, 'Appointment not found'); const d = byId(S().doctors, a.doctor_id); if (a.patient_id !== me.id && d.user_id !== me.id) throw HttpError(403, 'No access'); return { a, d }; }
R('GET', '/api/appointments/:id', 'any', async ({ me, m }) => apptView(apptAccess(me, m[1]).a));
R('GET', '/api/appointments/:id/messages', 'any', async ({ me, m }) => { apptAccess(me, m[1]); return S().msgs.filter(x => x.appointment_id === +m[1]); });
R('POST', '/api/appointments/:id/messages', 'any', async ({ me, m, body }) => { const { a } = apptAccess(me, m[1]); const text = String(body.text || '').trim(); need(text, 'Message is empty'); if (a.status === 'cancelled') throw HttpError(400, 'This appointment was cancelled');
  const o = { id: st.nid('g'), appointment_id: a.id, sender_role: me.role, sender_name: me.name, text, created_at: st.stamp() }; S().msgs.push(o); return o; });

/* doctor */
const dr = me => docByUser(me.id);
R('GET', '/api/doctor/dashboard', 'doctor', async ({ me }) => { const d = dr(me), s = S(), mine = s.appts.filter(a => a.doctor_id === d.id && a.status !== 'cancelled' && accessible(d, a.patient_id)), n = docNotifs(d);
  const todayA = mine.filter(a => a.slot.slice(0, 10) === st.today()).sort((a, b) => a.slot.localeCompare(b.slot)).map(apptView), up = mine.filter(a => a.slot.slice(0, 10) > st.today() && a.status === 'booked').sort((a, b) => a.slot.localeCompare(b.slot)).slice(0, 8).map(apptView);
  return { doctor: userView(me), stats: { today: todayA.length, patients: new Set(mine.map(a => a.patient_id)).size, completed: mine.filter(a => a.status === 'completed').length, follow_ups: n.filter(x => /follow_up/.test(x.kind)).length }, today: todayA, upcoming: up, notifications: n.slice(0, 6) }; });
R('GET', '/api/doctor/appointments', 'doctor', async ({ me }) => { const d = dr(me); return S().appts.filter(a => a.doctor_id === d.id && accessible(d, a.patient_id)).sort((a, b) => a.slot.localeCompare(b.slot)).map(apptView); });
R('GET', '/api/doctor/notifications', 'doctor', async ({ me }) => docNotifs(dr(me)));
R('GET', '/api/doctor/patients', 'doctor', async ({ me }) => { const d = dr(me), s = S(), n = docNotifs(d); const pids = [...new Set(s.appts.filter(a => a.doctor_id === d.id && a.status !== 'cancelled').map(a => a.patient_id))].filter(p => accessible(d, p));
  return pids.map(pid => { const rec = record(pid), ap = s.appts.filter(a => a.doctor_id === d.id && a.patient_id === pid && a.status !== 'cancelled'); const done = ap.filter(a => a.status === 'completed').sort((a, b) => b.slot.localeCompare(a.slot))[0], nxt = ap.filter(a => a.status !== 'completed').sort((a, b) => a.slot.localeCompare(b.slot))[0];
    return { id: pid, name: user(pid).name, age: rec.profile.age, gender: rec.profile.gender, blood_group: rec.profile.blood_group, visits: ap.filter(a => a.status === 'completed').length, conditions: rec.history.filter(h => h.status !== 'recovered').map(h => h.name), allergies: rec.allergies.map(a => a.allergen), flags: n.filter(x => x.patient_id === pid).map(x => x.text), last_visit: done ? done.slot : null, next_visit: nxt ? nxt.slot : null }; }).sort((a, b) => b.flags.length - a.flags.length); });
R('GET', '/api/doctor/patients/:id', 'doctor', async ({ me, m }) => { const d = dr(me), pid = +m[1]; if (!user(pid) || !accessible(d, pid)) throw HttpError(403, 'This patient has not shared their record with you'); const rec = record(pid), s = S();
  return { patient: { id: pid, name: user(pid).name, email: user(pid).email, profile: rec.profile }, history: rec.history, allergies: rec.allergies, medications: rec.medications, symptoms: rec.symptoms, reports: rec.reports, trends: rec.trends, consultations: s.consults.filter(c => c.completed_at && byId(s.appts, c.appointment_id).patient_id === pid).map(consView).sort((a, b) => b.completed_at.localeCompare(a.completed_at)), timeline: timeline(pid), appointments: s.appts.filter(a => a.patient_id === pid && a.doctor_id === d.id).map(apptView), notifications: docNotifs(d).filter(x => x.patient_id === pid) }; });
R('POST', '/api/doctor/patients/:id/ai-summary', 'doctor', async ({ me, m, q }) => { const d = dr(me), pid = +m[1]; if (!accessible(d, pid)) throw HttpError(403, 'No access'); const a = q.appointment_id ? byId(S().appts, q.appointment_id) : null; const b = await ai.brief(record(pid), a ? a.reason : ''); const c = a && S().consults.find(x => x.appointment_id === a.id); if (c) c.brief = b; return b; });
R('POST', '/api/doctor/appointments/:id/start', 'doctor', async ({ me, m }) => { const d = dr(me), a = byId(S().appts, m[1]); if (!a || a.doctor_id !== d.id) throw HttpError(404, 'Appointment not found'); if (a.status === 'cancelled' || a.status === 'completed') throw HttpError(400, 'This appointment is already ' + a.status);
  if (a.status === 'booked') { a.status = 'in_progress'; S().msgs.push({ id: st.nid('g'), appointment_id: a.id, sender_role: 'system', sender_name: 'System', text: `${me.name} has joined the consultation.`, created_at: st.stamp() }); }
  if (!S().consults.some(c => c.appointment_id === a.id)) S().consults.push({ id: st.nid('c'), appointment_id: a.id, notes: '', diagnosis: '', prescription: '', follow_up_date: null, follow_up_done: false, ai_summary: null, brief: null, completed_at: null }); return apptView(a); });
R('GET', '/api/doctor/consultations/by-appointment/:id', 'doctor', async ({ me, m }) => { const d = dr(me), a = byId(S().appts, m[1]); if (!a || a.doctor_id !== d.id) throw HttpError(404, 'Appointment not found'); const c = S().consults.find(x => x.appointment_id === a.id);
  return { appointment: apptView(a), consultation: c ? consView(c) : null, brief: c ? c.brief : null }; });
const ownCons = (me, id) => { const c = byId(S().consults, id), a = c && byId(S().appts, c.appointment_id); if (!c || byId(S().doctors, a.doctor_id).user_id !== me.id) throw HttpError(404, 'Consultation not found'); return { c, a }; };
R('PUT', '/api/doctor/consultations/:id', 'doctor', async ({ me, m, body }) => { const { c } = ownCons(me, m[1]); ['notes', 'diagnosis', 'prescription'].forEach(k => { if (k in body) c[k] = String(body[k] || ''); }); if ('follow_up_date' in body) c.follow_up_date = body.follow_up_date || null; return consView(c); });
R('POST', '/api/doctor/consultations/:id/complete', 'doctor', async ({ me, m, body }) => { const { c, a } = ownCons(me, m[1]); ['notes', 'diagnosis', 'prescription'].forEach(k => { if (k in body) c[k] = String(body[k] || ''); }); if ('follow_up_date' in body) c.follow_up_date = body.follow_up_date || null;
  const sum = await ai.consultSummary({ ...c, reason: a.reason }, S().msgs.filter(x => x.appointment_id === a.id), record(a.patient_id)); c.ai_summary = JSON.stringify(sum); c.completed_at = st.stamp(); a.status = 'completed';
  S().msgs.push({ id: st.nid('g'), appointment_id: a.id, sender_role: 'system', sender_name: 'System', text: 'Consultation completed. A summary was added to the patient record.', created_at: st.stamp() }); return consView(c); });
R('GET', '/api/doctor/consultations', 'doctor', async ({ me }) => { const d = dr(me); return S().consults.filter(c => c.completed_at && byId(S().appts, c.appointment_id).doctor_id === d.id).map(consView).sort((a, b) => b.completed_at.localeCompare(a.completed_at)); });
R('POST', '/api/doctor/consultations/:id/dismiss-followup', 'doctor', async ({ me, m }) => { const { c } = ownCons(me, m[1]); c.follow_up_done = true; return { ok: true }; });
R('POST', '/api/doctor/patients/:id/dismiss-followup', 'doctor', async ({ me, m }) => { const d = dr(me); S().consults.forEach(c => { const a = byId(S().appts, c.appointment_id); if (a.patient_id === +m[1] && a.doctor_id === d.id) c.follow_up_done = true; }); return { ok: true }; });
R('GET', '/api/health', null, async () => ({ ok: true, ai: ai.aiOn() ? 'gemini' : 'rules-only', db: process.env.DATABASE_URL || process.env.POSTGRES_URL ? 'postgres' : 'memory' }));

/* ---------- dispatcher ---------- */
async function readBody(req) { const ch = []; for await (const c of req) ch.push(c); return Buffer.concat(ch); }
async function handle(req, res) {
  const send = (code, obj) => { const b = JSON.stringify(obj); res.statusCode = code; res.setHeader('Content-Type', 'application/json'); res.setHeader('Cache-Control', 'no-store'); res.end(b); };
  try {
    await st.init();
    const u = new URL(req.url, 'http://x'); let path = u.pathname.replace(/^\/port\/\d+/, '').replace(/\/+$/, '') || '/'; const method = req.method === 'HEAD' ? 'GET' : req.method;
    if (method === 'OPTIONS') { res.statusCode = 204; return res.end(); }
    let hit = null, m = null; for (const r of routes) { if (r.method !== method) continue; const mm = path.match(r.re); if (mm) { hit = r; m = mm; break; } }
    if (!hit) return send(404, { detail: 'Not found' });
    const ctype = req.headers['content-type'] || ''; const raw = ['GET', 'DELETE'].includes(method) && !ctype ? Buffer.alloc(0) : await readBody(req); let body = {};
    if (/json/.test(ctype) && raw.length) { try { body = JSON.parse(raw.toString()); } catch { throw HttpError(400, 'Invalid JSON'); } }
    let me = null; if (hit.role) { const tok = (req.headers.authorization || '').replace(/^Bearer\s+/i, ''), p = st.decode(tok); me = p && user(p.sub); if (!me) throw HttpError(401, 'Please log in again'); if (hit.role !== 'any' && me.role !== hit.role) throw HttpError(403, `This area is for ${hit.role}s only`); }
    const out = await hit.fn({ me, body, raw, ctype, m, q: Object.fromEntries(u.searchParams) });
    if (method !== 'GET') st.persist(); send(200, out);
  } catch (e) { if (!e.code) console.error(e); send(e.code || 500, { detail: e.detail || 'Something went wrong on the server' }); }
}
module.exports = { handle };
