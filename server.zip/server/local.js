'use strict';
/* Local dev: node server/local.js  → http://localhost:3000 (serves the site + API together) */
const http = require('http'), fs = require('fs'), path = require('path'), { handle } = require('./routes');
const root = path.join(__dirname, '..'), types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2' };
http.createServer((req, res) => {
  if (req.url.startsWith('/api')) return handle(req, res);
  let p = decodeURIComponent(req.url.split('?')[0]); if (p === '/') p = '/index.html'; const f = path.join(root, p);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.statusCode = 404; return res.end('Not found'); }
  res.setHeader('Content-Type', types[path.extname(f)] || 'application/octet-stream'); fs.createReadStream(f).pipe(res);
}).listen(process.env.PORT || 3000, () => console.log('MedMemory AI on http://localhost:' + (process.env.PORT || 3000)));
