'use strict';
/* Real QR code via the `qrcode-svg` package (installed by `npm install` / Vercel). Encodes the emergency-card text. */
module.exports.svg = function (text) {
  try {
    const QR = require('qrcode-svg');
    return new QR({ content: text, padding: 1, width: 180, height: 180, color: '#000000', background: '#ffffff', ecl: 'M' }).svg();
  } catch (e) {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 180" width="180" height="180"><rect width="180" height="180" fill="#fff"/><text x="90" y="86" font-size="11" text-anchor="middle" fill="#000">QR needs</text><text x="90" y="102" font-size="11" text-anchor="middle" fill="#000">npm install</text></svg>';
  }
};
