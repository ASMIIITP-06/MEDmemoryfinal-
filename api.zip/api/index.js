const { handle } = require('../server/routes');
module.exports = (req, res) => handle(req, res);
