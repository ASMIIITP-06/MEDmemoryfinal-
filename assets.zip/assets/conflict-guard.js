/* Conflict Guard Live — interactive demo injected into the landing page (client-side, demo rules, no data leaves the browser) */
(function(){
const C={neck:'Neck strain · 33 days ago',pen:'Penicillin allergy',dia:'Type 2 diabetes · HbA1c 7.8',knee:'Knee injury · 2 months ago',asth:'Asthma',bp:'High blood pressure'};
const R={
 yoga:{q:'Suggest some yoga to reduce stress.',safe:['Slow deep breathing (5 min)','Seated cat-cow (gentle)','Legs-up-the-wall'],
  r:{neck:{a:['Headstand','Plough pose','Neck rolls'],w:'neck strain: inversions and neck loading can aggravate it'},
     bp:{a:['Inversions','Breath-holding practices'],w:'high BP: head-down poses and breath retention raise pressure'},
     asth:{a:['Forceful breathing (kapalbhati)'],w:'asthma: rapid forced breathing can trigger symptoms',s:['Slow nasal breathing']},
     knee:{a:['Full lotus','Deep kneeling poses'],w:'knee injury: deep knee flexion adds stress'}}},
 throat:{q:'I have a sore throat. What antibiotic should I take?',safe:['Warm salt-water gargle','Warm fluids and rest','See a doctor if fever lasts more than 3 days'],
  r:{pen:{a:['Penicillin-class antibiotics (e.g. amoxicillin)'],w:'recorded penicillin allergy',n:'Tell the doctor about your allergy before any prescription.'},
     dia:{a:[],w:'',s:['Check blood sugar more often while ill'],n:'Infections can push blood sugar up, so mention your diabetes to the doctor.'},
     asth:{a:[],w:'',n:'Keep your reliever inhaler handy if the throat infection affects your breathing.'}}},
 snack:{q:'Give me some evening snack ideas.',safe:['Fruit with a few nuts','Roasted chana','Unsalted makhana'],
  r:{dia:{a:['Mithai and sugary biscuits','Sweetened drinks'],w:'diabetes: fast sugars spike glucose',s:['Sugar-free dahi with seeds']},
     bp:{a:['Salted chips and namkeen','Papad and pickles'],w:'high BP: hidden salt raises pressure'}}},
 run:{q:'I want to start running every morning.',safe:['Start with brisk walking','Cycling or swimming for cardio','Build up gradually'],
  r:{knee:{a:['Hill running','Jump training'],w:'knee injury: high-impact load slows recovery',s:['Low-impact cycling or swimming first']},
     asth:{a:['Cold, dry-air runs without a warm-up'],w:'asthma: cold air can trigger symptoms',s:['5-minute warm-up and carry your inhaler']},
     bp:{a:['All-out sprints'],w:'high BP: sudden max effort spikes pressure',n:'Get your doctor to confirm a safe exercise level first.'}}},
 head:{q:'Which painkiller is best for my headache?',safe:['Rest in a quiet, dark room','Drink water','Seek urgent care for a sudden severe headache'],
  r:{asth:{a:['NSAIDs such as ibuprofen or aspirin'],w:'asthma: can trigger breathing problems in some people',n:'Ask a pharmacist or doctor which pain relief is safe for you.'},
     bp:{a:['Regular NSAID use'],w:'high BP: NSAIDs can raise blood pressure'},
     pen:{a:[],w:''}}}
};
const sel={c:new Set(['neck','pen']),q:'yoga'};
const esc=s=>String(s).replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));
function html(){
 return `<div class="in"><span class="tag"><i></i>UNIQUE FEATURE · LIVE</span>
 <h2>Conflict Guard <span class="text-primary">Live</span></h2>
 <p class="sb">Pick a patient's health memory, ask a question, and watch MedMemory block the suggestions that would conflict with that record. Nothing here is stored or sent anywhere.</p>
 <div class="gr"><div class="pn">
  <h4>1 · HEALTH MEMORY</h4><div class="chips">${Object.keys(C).map(k=>`<button class="ch cm" data-k="${k}">${C[k]}</button>`).join('')}</div>
  <h4>2 · ASK THE AI</h4><div class="chips">${Object.keys(R).map(k=>`<button class="ch rq" data-q="${k}">${R[k].q.replace(/\.$/,'')}</button>`).join('')}</div></div>
  <div class="pn" id="mmOut"></div></div></div>`}
function out(){
 const r=R[sel.q],ks=[...sel.c];let av=[],safe=r.safe.slice(),notes=[];
 ks.forEach(k=>{const x=r.r[k];if(!x)return;(x.a||[]).forEach(a=>av.push([a,x.w]));(x.s||[]).forEach(s=>safe.push(s));if(x.n)notes.push(x.n)});
 const hit=av.length;
 if(hit){const bad=new Set();av.forEach(a=>bad.add(a[0].toLowerCase()));safe=safe.filter(s=>!bad.has(s.toLowerCase()))}
 const used=ks.filter(k=>(r.r[k]));
 return `<div class="scan"></div>
 <div class="stat"><div><b>${ks.length}</b>records checked</div><div><b>${hit}</b>conflicts caught</div><div><b>0</b>unsafe tips shown</div></div>
 <div class="bub u">${esc(r.q)}</div>
 <div class="bub a">${ks.length?(hit?'I checked your record first and filtered this answer.':'I checked your record: no conflicts with this request.'):'No health memory selected, so this is generic advice.'}
  ${av.map(a=>`<div class="av"><span>AVOIDED</span><div>${esc(a[0])} <span class="why">— ${esc(a[1])}</span></div></div>`).join('')}
  ${safe.map(s=>`<div class="ok"><span>SAFE</span><div>${esc(s)}</div></div>`).join('')}
  ${notes.map(n=>`<div class="wn">${esc(n)}</div>`).join('')}
  ${used.length?`<div style="margin-top:12px;font-size:12px;color:#a9c9b8">Used: ${used.map(k=>esc(C[k])).join(' · ')}</div>`:''}</div>
 <small>Demo rules for illustration only. Not medical advice. Always consult a doctor.</small>`}
function paint(root){
 root.querySelectorAll('.cm').forEach(b=>b.classList.toggle('on',sel.c.has(b.dataset.k)));
 root.querySelectorAll('.rq').forEach(b=>b.classList.toggle('on',sel.q===b.dataset.q));
 root.querySelector('#mmOut').innerHTML=out();
}
function mount(){
 if(!/^#?\/?$/.test(location.hash)&&location.hash!=='#/')return;
 if(document.getElementById('mm-guard'))return;
 const sec=[...document.querySelectorAll('section')].find(s=>/What makes it different/.test(s.textContent||''));
 if(!sec)return;
 const el=document.createElement('section');el.id='mm-guard';el.innerHTML=html();sec.after(el);
 el.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
  if(b.dataset.k){sel.c.has(b.dataset.k)?sel.c.delete(b.dataset.k):sel.c.add(b.dataset.k)}
  if(b.dataset.q)sel.q=b.dataset.q;paint(el)});
 paint(el);
}
new MutationObserver(mount).observe(document.documentElement,{childList:true,subtree:true});
addEventListener('hashchange',mount);mount();
})();
